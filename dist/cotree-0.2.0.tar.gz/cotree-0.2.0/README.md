# COTree

This is a Python implementation of COTree framework developed for multi-omics cell trajectory data analysis.

A complete working example is located in COTree.ipynb.

## Install
```bash
pip install COTree .
```

## Usage
```python
import cotree
print(cotree.__version__)
```
Available modules:
- driver_species_detection, DTMAE, function_module_detection, granger_causality_test, tree
